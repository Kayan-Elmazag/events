document.addEventListener('DOMContentLoaded', function() {
  // تحميل اسم المستخدم
  const userData = JSON.parse(localStorage.getItem('userData')) || {};
  const usernameElement = document.getElementById('username');
  if (usernameElement && userData.fullName) {
    usernameElement.textContent = userData.fullName;
  }

  // إعداد زر تسجيل الخروج
  const logoutBtn = document.querySelector('.logout-link');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      Swal.fire({
        title: 'تأكيد تسجيل الخروج',
        text: 'هل أنت متأكد أنك تريد تسجيل الخروج؟',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'نعم، سجل خروج',
        cancelButtonText: 'إلغاء'
      }).then((result) => {
        if (result.isConfirmed) {
          // مسح بيانات الجلسة
          localStorage.removeItem('sessionToken');
          localStorage.removeItem('userData');
          
          // التوجيه لصفحة تسجيل الدخول
          window.location.href = 'login.html';
        }
      });
    });
  }
});