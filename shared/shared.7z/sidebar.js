/**
 * Initialize sidebar functionality
 * This will be called from main.js after loading the sidebar
 */
function initializeSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const sidebarToggle = document.querySelector('.sidebar-toggle');
  const overlay = document.querySelector('.overlay');
  
  // Create toggle button if not exists
  if (!sidebarToggle) {
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'sidebar-toggle';
    toggleBtn.innerHTML = '<i class="bx bx-menu"></i>';
    document.body.appendChild(toggleBtn);
  }
  
  // Create overlay if not exists
  if (!overlay) {
    const overlayDiv = document.createElement('div');
    overlayDiv.className = 'overlay';
    document.body.appendChild(overlayDiv);
  }
  
  // Toggle sidebar when button is clicked
  document.addEventListener('click', function(e) {
    if (e.target.closest('.sidebar-toggle')) {
      sidebar.classList.toggle('active');
      document.querySelector('.overlay').classList.toggle('active');
    }
    
    // Close sidebar when clicking outside
    if (e.target.classList.contains('overlay')) {
      sidebar.classList.remove('active');
      e.target.classList.remove('active');
    }
  });
  
  // Close sidebar when clicking on a link (optional)
  const sidebarLinks = document.querySelectorAll('.sidebar a');
  sidebarLinks.forEach(link => {
    link.addEventListener('click', () => {
      sidebar.classList.remove('active');
      document.querySelector('.overlay').classList.remove('active');
    });
  });
}